import mongoose from "mongoose";

import { connectDB } from "../config/db.js";
import { clerkClient } from "../config/clerk.js";
import {
  initializeUserLifecycle,
} from "../services/userLifecycleInitialization.service.js";
import User from "../models/user.model.js";
import dotenv from "dotenv";
dotenv.config();

// ==================================================
// TEST USER CONFIGURATION
// ==================================================

const TEST_USER = {
  firstName: "Brett",

  lastName: "Admin",

  username: "brettjonas",

  email:process.env.TEST_USER_EMAIL,

  password: process.env.TEST_USER_PASSWORD,
    role: "super_admin",

};

// ==================================================
// CREATE TEST USER
// ==================================================

const createTestUser = async () => {
  let clerkUser = null;

  try {
    // ------------------------------------------------
    // CONNECT DATABASE
    // ------------------------------------------------

    await connectDB();

    console.log(
      "Database connected."
    );

    // ------------------------------------------------
    // CHECK MONGODB USER
    // ------------------------------------------------

    const existingUser =
      await User.findOne({
        email: TEST_USER.email,
      });

    if (existingUser) {
      console.log(
        "MongoDB test user already exists."
      );

    

      return;
    }

    // ------------------------------------------------
    // CHECK CLERK USER
    // ------------------------------------------------

    try {
      clerkUser =
        await clerkClient.users.createUser({
          emailAddress: [
            TEST_USER.email,
          ],

          username:
            TEST_USER.username,

          firstName:
            TEST_USER.firstName,

          lastName:
            TEST_USER.lastName,

          password:
            TEST_USER.password,
        });

      console.log(
        "Clerk test user created."
      );

      console.log(
        "Clerk User ID:",
        clerkUser.id
      );
    } catch (error) {
      console.error(
        "Failed to create Clerk user:",
        error
      );

      return;
    }

    // ------------------------------------------------
    // CREATE MONGODB USER
    // ------------------------------------------------

    let user;

    try {
      user =
        await User.create({
          clerkId:
            clerkUser.id,

          firstName:
            TEST_USER.firstName,

          lastName:
            TEST_USER.lastName,

          username:
            TEST_USER.username,

          email:
            TEST_USER.email,
        });

      console.log(
        "MongoDB test user created."
      );

      console.log(
        "MongoDB User ID:",
        user._id
      );
      await initializeUserLifecycle(user._id);
    } catch (error) {
      // ----------------------------------------------
      // ROLLBACK CLERK USER
      // ----------------------------------------------

      console.error(
        "Failed to create MongoDB user:",
        error
      );

      if (clerkUser) {
        try {
          await clerkClient.users.deleteUser(
            clerkUser.id
          );

          console.log(
            "Clerk user rollback completed."
          );
        } catch (
          rollbackError
        ) {
          console.error(
            "Failed to rollback Clerk user:",
            rollbackError
          );
        }
      }

      return;
    }

  
    // ------------------------------------------------
    // COMPLETE
    // ------------------------------------------------

    console.log(
      "Test user creation completed successfully."
    );
  } catch (error) {
    console.error(
      "Create test user error:",
      error
    );
  } finally {
    // ------------------------------------------------
    // DISCONNECT DATABASE
    // ------------------------------------------------

    await mongoose.connection.close();

    console.log(
      "Database connection closed."
    );
  }
};

// ==================================================
// RUN SCRIPT
// ==================================================

createTestUser();