import "dotenv/config";

// import { clerkClient } from "../config/clerk.js"
import {clerkClient} from "../config/clerk.js"
const clerkUserId = process.argv[2];

if (!clerkUserId?.startsWith("user_")) {
  console.error(
    "Usage: node scripts/test-clerk-sessions.js <clerkUserId>"
  );
  process.exit(1);
}

try {
  const result =
    await clerkClient.sessions.getSessionList({
      userId: clerkUserId,
      limit: 100,
      offset: 0,
    });

  console.log("Total Sessions:", result.totalCount);

  console.table(
    result.data.map((session) => ({
      id: session.id,
      userId: session.userId,
      status: session.status,
      createdAt: session.createdAt,
    }))
  );
} catch (error) {
  console.error("Clerk Session Inventory Failed", {
    status: error.status,
    errors: error.errors?.map((item) => ({
      code: item.code,
      message: item.message,
    })),
  });

  process.exitCode = 1;
}