import "dotenv/config";

import { clerkClient } from "../config/clerk.js";

const [clerkUserId, sessionId] =
  process.argv.slice(2);

if (
  !clerkUserId?.startsWith("user_") ||
  !sessionId?.startsWith("sess_")
) {
  console.error(
    "Usage: node scripts/test-clerk-revocation.js <clerkUserId> <sessionId>"
  );

  process.exit(1);
}

try {
  // 1. Verify session ownership
  const before =
    await clerkClient.sessions.getSession(
      sessionId
    );

  if (before.userId !== clerkUserId) {
    throw new Error(
      "Session does not belong to the specified Clerk user."
    );
  }

  if (before.status !== "active") {
    throw new Error(
      `Session is not active: ${before.status}`
    );
  }

  console.log("Before:", before.status);

  // 2. Revoke session
  await clerkClient.sessions.revokeSession(
    sessionId
  );

  // 3. Verify revocation
  const after =
    await clerkClient.sessions.getSession(
      sessionId
    );

  console.log("After:", after.status);

  if (after.status !== "revoked") {
    throw new Error(
      "Session revocation could not be confirmed."
    );
  }

  console.log(
    "SUCCESS: Clerk session revoked."
  );
} catch (error) {
  console.error(
    "Session Revocation Test Failed:",
    {
      status: error.status,
      code: error.code,
      message: error.message,
    }
  );

  process.exitCode = 1;
}